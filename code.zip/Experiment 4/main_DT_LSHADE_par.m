%% DT_LSHADE 并行计算
clear all
%global noPro 
%%

StrAlgorithm=['All_Data_DT_LSHADE_1'];
datapath = 'DT_LSHADE_DATA_PATH';  % 为每次实验设置不同的数据保存文件夹
opt.algName = 'DT_LSHADE';  % 填写算法名称
opt.comments = 'DT_LSHADE noisy';  % 填写更详细的信息，比如参数设置等
%% 范围和问题
VRmin=-5;
VRmax=5;
tempfile=[];
noPro0=benchmarksnoisy('FunctionIndices');
%% 重复试验次数
repNum=32;
optimum_objs2=zeros(repNum,length(noPro0));
%%
rng('default')
mainSeed = 1;
% 创建一个随机数流对象元启发算法一般都是用于求解连续型问题的，最经典的应用场景为Industrial chemical process problems，Process design and synthesis problems，Mechanical design problems，Power system problems，Power Electronic Problems，Livestock Feed Ration Optimization等ream = RandStream('mt19937ar', 'Seed', mainSeed);
seeds = cell(1, repNum);
for i = 1:repNum
    seeds{i} = RandStream('mt19937ar', 'Seed', mainSeed + i);
end
%%
%parpool(12);
Dimension0=[5,10,15,20];
result1=[];
tic
for ii=1:length(Dimension0)             %不同维度
    Dimension=Dimension0(ii);
    for k=1:1  
        for i=1:length(noPro0)          %不同问题
            noPro=noPro0(length(noPro0)-i+1);
            tempfile=[noPro];
            parfor j=1:repNum              %重复试验
                ifun=noPro;
                iinstance=j;
                % 获取当前迭代的随机数流
                currentStream = seeds{j};
                % 设置当前工作者的随机数流
                RandStream.setGlobalStream(currentStream);
                fgeneric('initialize', ifun, iinstance, datapath, opt);  % 初始化测试函数
                [~,optimum_objs2(j,i),~] =func_DT_LSHADE(Dimension,VRmin,VRmax,tempfile);
                fbest=fgeneric('fbest');
                ftarget=fgeneric('ftarget');
                optimum_objs2(j,i)=fbest-ftarget;
                disp([num2str(ii),'-',num2str(k),'-',num2str(i),'-',num2str(j),'-',num2str(optimum_objs2(j,i))])
                fgeneric('finalize');
            end
            disp(num2str(mean(optimum_objs2(:,i))));
        end
        R{ii,k}=optimum_objs2;
    end
end
tt=toc
disp(StrAlgorithm)
%%
str=['CECE2020-',StrAlgorithm];
save([str,date,'-',num2str(Dimension)],'R')
%%
meanObj=[];
for ii=1:length(Dimension0)  
    meanObj=[meanObj,mean(R{ii})];
end
