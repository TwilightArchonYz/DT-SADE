function [x_r,y_r]=getXY(index,x,y,numAgent)
    PopSize=length(index);
    index=index(randi(PopSize,numAgent,1));
    x_r=x(index,:);
    y_r=y(index,:);
end