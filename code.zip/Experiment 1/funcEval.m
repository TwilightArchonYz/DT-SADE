function [y,x]=funcEval(x,noPro)
    %global noPro
    x=x';
    y=cec20_func(x,noPro);
    y=y';
end