function f_trans = DTEO(x,f,Thes)
[Np,D] = size(x);
f_trans = [];
for j = 1 : D
    [~,x_address] = sort(x(:,j));
    fs = f(x_address);
    f_fft = fft(fs,Np);
    f_fftshift = fftshift(f_fft);

    if Thes > 0
        f_fftshift(1 : ceil(Np * Thes)) = 0;
        f_fftshift(Np - ceil(Np * Thes) + 1: Np) = 0;
    end

    f_fft = ifftshift(f_fftshift);
    y = real(ifft(f_fft, Np));
    y(x_address) = y;
    f_trans_j = y;
    f_trans = [f_trans,f_trans_j];
end
f_trans = mean(f_trans,2);
% figure
% hold on
% plot(fs)
% plot(f_trans)
end