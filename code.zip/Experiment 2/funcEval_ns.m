function [y,x]=funcEval_ns(x,var)
    noPro=var(1);
    noise_strength=var(2);
    %global noPro
    %y=cec20_func(x,noPro);
    y =  funcEval(x,noPro);
    y = Gaussian_Noise(y,noise_strength);

end