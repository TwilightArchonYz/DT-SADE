%% DT_JSO 并行计算
clear all
%global noPro 
%%

StrAlgorithm=['All_Data_DT_JSO_ns1-'];

%% 范围和问题
VRmin=-100;
VRmax=100;
tempfile=[];
noPro0=1:10;
%% 重复试验次数
repNum=32;
optimum_objs2=zeros(repNum,length(noPro0));
%%
rng('default')
mainSeed = 1;
% 创建一个随机数流对象元启发算法一般都是用于求解连续型问题的，最经典的应用场景为Industrial chemical process problems，Process design and synthesis problems，Mechanical design problems，Power system problems，Power Electronic Problems，Livestock Feed Ration Optimization等ream = RandStream('mt19937ar', 'Seed', mainSeed);
seeds = cell(1, repNum);
for i = 1:repNum
    seeds{i} = RandStream('mt19937ar', 'Seed', mainSeed + i);
end
%%
%parpool(12);
Dimension0=[5,10,15,20];
noise_strength=0.1;
result1=[];
tic
for ii=1:length(Dimension0)             %不同维度
    Dimension=Dimension0(ii);
    for k=1:1  
        for i=1:length(noPro0)          %不同问题
            noPro=noPro0(length(noPro0)-i+1);
            tempfile=[noPro,noise_strength];
            parfor j=1:repNum              %重复试验
                % 获取当前迭代的随机数流
                currentStream = seeds{j};
                % 设置当前工作者的随机数流
                RandStream.setGlobalStream(currentStream);
                [~,optimum_objs2(j,i),~] =func_DT_jSO(Dimension,VRmin,VRmax,tempfile);
                disp([num2str(ii),'-',num2str(k),'-',num2str(i),'-',num2str(j),'-',num2str(optimum_objs2(j,i))])
            end
            disp(num2str(mean(optimum_objs2(:,i))));
        end
        R{ii,k}=optimum_objs2;
    end
end
tt=toc
disp(StrAlgorithm)
%%
str=['CECE2020-',StrAlgorithm];
save([str,date,'-',num2str(Dimension)],'R')
%%
meanObj=[];
for ii=1:length(Dimension0)  
    meanObj=[meanObj,mean(R{ii})];
end