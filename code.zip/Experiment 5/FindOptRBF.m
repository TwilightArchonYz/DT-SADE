function  opt = FindOptRBF(model,Population,BU,BD)
% Find the minimum of the surrogate

%------------------------------- Copyright --------------------------------
% Copyright (c) 2024 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    [~,I]  = sort(Population.y,'ascend');
    init   = 1;
    %opt = fmincon(@(x)sim(model,x),Population.x(I(init),:)',[],[],[],[],BD',BU',[],optimoptions('fmincon','Display','off'));
    preObj = sim(model,Population.x(I(init),:)')';
    
    if isnan(preObj)
        F=0;
    else
        F=1;
    end
    if F==1
        try
            opt = fmincon(@(x)sim(model,x),Population.x(I(init),:)',[],[],[],[],BD',BU',[],optimoptions('fmincon','Display','off'));
            opt=opt';
        catch
            opt=Population.x(I(1,:),:)+0.01*randn(size(Population.x(1,:)));
        end
    else
        opt=Population.x(I(1,:),:)+0.01*randn(size(Population.x(1,:)));
    end
end