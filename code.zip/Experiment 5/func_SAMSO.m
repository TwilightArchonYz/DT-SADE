
function [gbest,gbestval,recording] =  func_SAMSO(dimension,xmin,xmax,tempfile)
    %% Parameter setting
    recording=[];
    Wnc=1;
    Pr=0.5;
    Problem.N=50;
    Problem.D=dimension;
    Problem.lower=xmin+zeros(1,Problem.D);
    Problem.upper=xmax+zeros(1,Problem.D);
    Problem.noPro=tempfile;
    Problem.maxFE=  5000;
    eta      = min(sqrt(0.001^2*Problem.D),5e-4*min(Problem.upper-Problem.lower));
    
    %% Initialze DB
    if Problem.D > 50
        N = 80;
        K = 2*Problem.D;
    else
        N = 40;
        K = N;
    end
    Problem.N=N;
    Problem.K=K;
    
    %%
    PopDec = UniformPoint(K,Problem.D,'Latin');
    PopDec = repmat(Problem.upper-Problem.lower,K,1).*PopDec+repmat(Problem.lower,K,1);
    Population.x=PopDec;
    Population.y=funcEval(Population.x,Problem.noPro); %mablatb
    %%
    [gbestval,no]=min(Population.y);
    gbest=Population.x(no,:);
    %gbestval=Population.y(no);
    
    %% Initialize swarm
    % Determine position
    [~,idx]  = sort(Population.y,'ascend');
    Select   = idx(1:N);
    Position = [Population.x(Select,:),Population.y(Select,:)];
    % velocity
    Vmax     = 0.5*(Problem.upper-Problem.lower);
    Vmin     = -0.5*Vmax;
    Velocity = rand(N,Problem.D).*(repmat(Vmax-Vmin,N,1)) + repmat(Vmin,N,1);
    % Pbest and Gbest
    Pbest    = Position;
    Gbest    = Position(1,:);
    maxFES   = Problem.maxFE;
    FES=Problem.K;
    %% Optimization
    while FES<Problem.maxFE
        %disp(FES)
        % Build RBF surrogate model
        maxSap=1000;
        if FES>maxSap
            Population0.x=Population.x(end-maxSap+1:end,:);
            Population0.y=Population.y(end-maxSap+1:end,:);
        else
            Population0=Population;
        end
        [model,~] = rbf_build(Population0.x,Population0.y);
        % Find the minimum of the surrogate
        srgtMin = FindOpt(model,Population0,Problem.upper,Problem.lower);

        % Calculate distance
        dist  = pdist2(Population.x,srgtMin);
        dxRBF = min(dist);
        if dxRBF > eta
            optSrgt    =funcEval(srgtMin,Problem.noPro); %mablatb
            FES=FES+1;
            %optSrgt    = Problem.Evaluation(srgtMin);
            Population.x=[Population.x;srgtMin];
            Population.y=[Population.y;optSrgt];
            %Population = [Population,optSrgt];
            if optSrgt < Gbest(:,end)
                if FES>maxSap
                    Population0.x=Population.x(end-maxSap+1:end,:);
                    Population0.y=Population.y(end-maxSap+1:end,:);
                else
                    Population0=Population;
                end
                [model,~] = rbf_build(Population0.x,Population0.y);
                Gbest     = [srgtMin,optSrgt];
            end
        end
        currFES = FES;
        [Population,Position,Velocity,Gbest,Pbest,increFES] = UpdatePosition(Problem,Population,Position,Velocity,Pbest,Gbest,currFES,maxFES,Wnc,Pr,model,eta);
        %disp(num2str([FES,Gbest(1,end)]))
        FES=FES+increFES;
    end
    [gbestval,no]=min(Population.y);
    gbest=Population.x(no,:);
    gbestval=funcEval(gbest,Problem.noPro); %mablatb
end