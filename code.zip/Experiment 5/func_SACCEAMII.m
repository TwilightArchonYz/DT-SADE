
function [gbest,gbestval,recording] =  func_SACCEAMII(dimension,xmin,xmax,tempfile)
%% Parameter setting
recording=[];
Wnc=1;
Pr=0.5;
Problem.N=50;
Problem.D=dimension;
Problem.lower=xmin+zeros(1,Problem.D);
Problem.upper=xmax+zeros(1,Problem.D);
Problem.maxFE=  5000;
Problem.noPro=tempfile;

%% Parameter setting
s = 50;

%% Separable decision variable grouping
BU = Problem.lower;
BD = Problem.upper;
D  = Problem.D;
[Population,Groups,K] = spiltVariables(Problem,BU,BD,s);
FES=length(Population.y);
%% Initialize each component
% Start point
GlobalIndi  = rand(1,D).*(BU-BD) + BD;
%GlobalObj   = Problem.Evaluation(GlobalIndi);
GlobalObj =EvaluationXY(GlobalIndi,Problem);
FES=FES+length(GlobalObj.y);
Population=mergePopulation(Population,GlobalObj);
%Population  = [Population,GlobalObj];
Fmin        = GlobalObj.y;
GlobalCandi = GlobalIndi;
% Otain best solution of each component
database = cell(1,K);
for i = 1 : K
    select = Groups == i;
    subD   = sum(select);
    subN   = subD + 1;
    RepGlobal = repmat(GlobalIndi,subN,1);
    Decs   = rand(subN,subD).*repmat(BU(select)-BD(select),subN,1) + repmat(BD(select),subN,1);
    RepGlobal(:,select) = Decs;
    %news   = Problem.Evaluation(RepGlobal);
    news =EvaluationXY(RepGlobal,Problem);
    FES=FES+length(news.y);
    database{i} = news;
    %Population  = [Population,news];
    Population=mergePopulation(Population,news);
    [~,best]    = min(news.y);
    BestDec     = news.x(best,:);
    GlobalCandi(select) = BestDec(select);
end
% Evaluate the global candidate
%NewCandi   = Problem.Evaluation(GlobalCandi);
NewCandi =EvaluationXY(GlobalCandi,Problem);
CandiObj   = NewCandi.y;
%Population = [Population,NewCandi];
Population=mergePopulation(Population,NewCandi);
if CandiObj < Fmin
    Fmin = CandiObj;
    GlobalIndi = GlobalCandi;
end
%% Optimization
while FES<Problem.maxFE
    for i = 1 : K
        tGlobalIndi = GlobalIndi;
        select = Groups == i;

        if length(database{i}.y)>1000
            database{i}.x=database{i}.x(end-1000:end,:);
            database{i}.y=database{i}.y(end-1000:end,:);
        end
        Decs   = database{i}.x;
        Objs   = database{i}.y;
        [model,~] = rbf_build(Decs(:,select),Objs);
        PopSize   = 10*sum(select);
        ProposedPoint       = GAOptimize(model,PopSize,Decs(:,select),BU(select),BD(select));
        tGlobalIndi(select) = ProposedPoint;
        %newPropose    = Problem.Evaluation(tGlobalIndi);
        newPropose =EvaluationXY(tGlobalIndi,Problem);
        FES=FES+length(newPropose.y);
        database{i}=mergePopulation(database{i},newPropose);
        %database{i}   = [database{i},newPropose];
        if newPropose.y < CandiObj
            decs = newPropose.x;
            GlobalCandi(select) = decs(select);
            CandiObj = newPropose.y;
        end
        Population=mergePopulation(Population,newPropose);
        %Population = [Population,newPropose];
    end
    %new = Problem.Evaluation(GlobalCandi);
    new =EvaluationXY(GlobalCandi,Problem);
    FES=FES+length(new.y);
    %Population = [Population,new];
    Population=mergePopulation(Population,new);
    if new.y < Fmin
        Fmin = new.y;
        GlobalIndi = GlobalCandi;
    end
    %disp(FES)
end
%[gbestval,no]=min(Population.y);
gbest=GlobalIndi;
gbestval=funcEval(gbest,Problem.noPro); %mablatb
end