function  opt = FindOpt(model,Population,BU,BD)
% Find the minimum of the surrogate

%------------------------------- Copyright --------------------------------
% Copyright (c) 2024 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    [~,I]  = sort(Population.y,'ascend');
    init   = 1;
    preObj = rbf_predict(model,Population.x,Population.x(I(init),:));
    F=0;
    while isnan(preObj)
        init   = init + 1;
        if init>length(I)
            F=1;
            break;
        end
        preObj = rbf_predict(model,Population.x,Population.x(I(init),:));
        
    end
    if F==0
        try
            opt = fmincon(@(x)rbf_predict(model,Population.x,x),Population.x(I(init),:),[],[],[],[],BD,BU,[],optimoptions('fmincon','Display','off'));
        catch
            opt=Population.x(I(1,:),:)+0.01*randn(size(Population.x(1,:)));
        end
    else
        opt=Population.x(I(1,:),:)+0.01*randn(size(Population.x(1,:)));
    end
end