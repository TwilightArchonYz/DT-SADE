function  opt = FindOptKRG_DE(model,Population,BU,BL,Thes)
% Find the minimum of the surrogate

%------------------------------- Copyright --------------------------------
% Copyright (c) 2024 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------
%[~,I]  = sort(Population.y,'ascend');
%init   = 1;
%opt = fmincon(@(x)sim(model,x),Population.x(I(init),:)',[],[],[],[],BD',BU',[],optimoptions('fmincon','Display','off'));
%preObj = sim(model,Population.x(I(init),:)')';
%preObj =predictor(Population.x, model);
x=Population.x;
y=predictor(x, model);
[y_best,index]=min(y);
x_best=x(index,:);
for t=1:100
    NP=length(x(:,1));
    r_ind=randi(NP,NP,2);
    for i=1:NP
        r1=r_ind(i,1);
        r2=r_ind(i,2);
        newX(i,:)=x_best+0.1*(x(r1,:)-x(r2,:));
        ind=newX(i,:)>BU;
        newX(i,ind)=BU(ind);
        ind=newX(i,:)<BL;
        newX(i,ind)=BL(ind);
    end
    newY=predictor(newX, model);
    u_val_f = newY;
    tempX=[x;newX];
    tempY=[y;newY];
    f_trans = DTEO([x;newX],[y;newY],Thes);
    fitness = f_trans(1 : NP);
    children_fitness = f_trans(NP + 1 : 2 * NP);
    for i=1:NP
        if fitness(i)<children_fitness(i)
            x(i,:)=newX(i,:);
        end
    end
    [~,index]=min(f_trans);
    x_best=tempX(index,:);
    y_best=tempY(index,:);
end
opt=x_best;
