
function [gbest,gbestval,recording] =  func_SACOSO(dimension,xmin,xmax,tempfile)
    %% Parameter setting
    recording=[];
    Wnc=1;
    Pr=0.5;
    Problem.N=50;
    Problem.D=dimension;
    Problem.lower=xmin+zeros(1,Problem.D);
    Problem.upper=xmax+zeros(1,Problem.D);
    Problem.maxFE=  5000;
    Problem.noPro=tempfile;
    eta      = min(sqrt(0.001^2*Problem.D),5e-4*min(Problem.upper-Problem.lower));
    
    %% Parameter setting
    NFES=30;
    NRBF=200;
    %% Generate the random population
    N          = NFES + NRBF;
    PopDec     = UniformPoint(N,Problem.D,'Latin');
    PopDec     = repmat(Problem.upper-Problem.lower,N,1).*PopDec+repmat(Problem.lower,N,1);
    Population.x=PopDec;
    Population.y=funcEval(Population.x,Problem.noPro); %mablatb
    
    
    
    MaxNode    = 8;
    NDB        = MaxNode*Problem.D+10;
    BU         = Problem.upper;
    BD         = Problem.lower;
    
    %% Initialize each swarm
    % FES-assisted swarm
    PosFES   = Population.x(1:NFES,:);
    ObjFES   = Population.y(1:NFES,:);
    SwarmFES = [PosFES,ObjFES];
    PbestFES = SwarmFES;
    PBEval   = true(N,1);
    notEval  = false(NFES,1);
    notEST   = false(NFES,1);
    [~,best] = min(SwarmFES(:,end));
    GbestFES = SwarmFES(best,:);
    VelFES   = repmat(BU-BD,NFES,1).*rand(NFES,1)+repmat(BD,NFES,1);
    % RBF-assisted SL-PSO
    PosRBF   = Population.x(NFES+1:NFES+NRBF,:);
    ObjRBF   = Population.y(NFES+1:NFES+NRBF,:);
    SwarmRBF = [PosRBF,ObjRBF];
    [~,best] = min(SwarmRBF(:,end));
    GbestRBF = SwarmRBF(best,:);
    DeltaRBF = repmat(BU-BD,NRBF,1).*rand(NRBF,1)+repmat(BD,NRBF,1);
    
    %% Optimization
    SwarmFESt = SwarmFES;
    SpreadSum = 0;
    Archive   = Population;
    iter      = 1;
    FES       = N;
    %% Optimization
    while FES<Problem.maxFE
        % Determine global best solution
        if GbestFES(:,end) < GbestRBF(:,end)
            Gbest = GbestFES;
        else
            Gbest = GbestRBF;
        end
    
        % Paramaters of RBFNN
        SpreadSum = SpreadSum + sqrt(sum((max(Population.x,[],1)-min(Population.x,[],1)).^2));
        Spread    = SpreadSum/iter;
    
        % Build RBFNN surrogate model
        net = srgtsnewrb(Population.x',Population.y',0.1,Spread,MaxNode,1,'off');
    
        % FES-assisted PSO
        SwarmFESt1 = SwarmFESt;
        SwarmFESt  = SwarmFES;
        [tArchive,SwarmFES,VelFES,PbestFES,GbestFES,notEval,notEST,PBEval,countFES] = FESPSO(iter,net,SwarmFES,VelFES,PbestFES,GbestFES,GbestRBF,Problem,notEval,notEST,PBEval,SwarmFESt1,SwarmFESt);
        FES=FES+countFES;
        % Select demonstrators
        Select = randperm(length(Population.y),NRBF);
        Demons = [SwarmRBF;Population.x(Select,:),Population.y(Select,:)];
        % RBF-assisted SL-PSO
        [SwarmRBF,DeltaRBF] = RBFOperator(net,Demons,SwarmRBF,DeltaRBF,Gbest,Problem);
        [tArchive,GbestRBF,countFES] = UpdateRBF(Problem,tArchive,SwarmRBF,GbestRBF);
        FES=FES+countFES;
        % Updating archive DB
        Population.x = [Population.x;tArchive.x];
        Population.y = [Population.y;tArchive.y];
        Archive    = UpdateArchive(Archive,tArchive,SwarmRBF,NDB);
        iter       = iter + 1;
    end
    [gbestval,no]=min(Population.y);
    gbest=Population.x(no,:);
    gbestval=funcEval(gbest,Problem.noPro); %mablatb
end