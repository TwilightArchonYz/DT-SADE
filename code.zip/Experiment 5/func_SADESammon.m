
function [gbest,gbestval,recording] = func_SADESammon(dimension,xmin,xmax,tempfile)
    %% Parameter setting
    recording=[];
    Problem.N=50;
    Problem.D=dimension;
    Problem.lower=xmin+zeros(1,Problem.D);
    Problem.upper=xmax+zeros(1,Problem.D);
    Problem.maxFE=  5000;
    Problem.noPro=tempfile;
    %% Parameter setting
    Mu=0.5;
    CR=0.5;
    LD=4;
    Omiga=2;
    Lammda=50;
    %% Generate the random population
    N          = 2*Problem.D;
    Problem.N  = N;
    PopDec = UniformPoint(Problem.N,Problem.D,'Latin');
    PopDec = repmat(Problem.upper-Problem.lower,N,1).*PopDec+repmat(Problem.lower,N,1);
    Population.x=PopDec;
    Population.y=funcEval(Population.x,Problem.noPro); %mablatb
    %%
    [gbestval,no]=min(Population.y);
    gbest=Population.x(no,:);
    %%
    FES=Problem.N;
    %% Optimization
    while FES<Problem.maxFE
        % Generate Lammda new solution with DE
        Lammda = min(Lammda,length(Population.y));
        newDec = GenerateNew(Problem,Population,Lammda,Mu,CR);

        % Map data to low dimension using Sammon mapping
        trainDec = Population.x(end-N+1:end,:);
        trainObj = Population.y(end-N+1:end,:);
        sdrDec   = Sammon([trainDec;newDec],LD);

        % Build Kriging surrogate model
        try
            dmodel = dacefit(sdrDec(1:N,:),trainObj,'regpoly1','corrgauss',0.002);
            [yhat,predvar] = predictor(sdrDec(N+1:end,:), dmodel);
        catch
            continue;
        end

        % Obtain LCB
        LCB = yhat - Omiga*predvar;

        % Evaluate
        [~,best] = min(LCB);
        newX=PopDec;
        newY=funcEval(newX(best,:),Problem.noPro); %mablatb
        Population.x=[Population.x;newX(best,:)];
        Population.y=[Population.y;newY];
        FES=FES+1;
    end
    [gbestval,no]=min(Population.y);
    gbest=Population.x(no,:);
    gbestval=funcEval(gbest,Problem.noPro); %mablatb
end