function [y,x]=funcEval(x,FUN)
    FUN='fgeneric';
    y=feval(FUN, x');
    y=y';
end